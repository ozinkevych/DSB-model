<?php

namespace Drupal\webform;

/**
 * A base exception thrown in any webform exception.
 */
class WebformException extends \RuntimeException {}
