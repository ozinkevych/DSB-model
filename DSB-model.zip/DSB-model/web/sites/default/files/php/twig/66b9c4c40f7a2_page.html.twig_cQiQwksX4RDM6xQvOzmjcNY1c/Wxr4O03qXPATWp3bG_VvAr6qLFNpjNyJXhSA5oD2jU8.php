<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* themes/custom/exam/templates/layout/page.html.twig */
class __TwigTemplate_a5448ab286244a564283c7f8a875b49c extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'content' => [$this, 'block_content'],
            'footer' => [$this, 'block_footer'],
        ];
        $this->sandbox = $this->env->getExtension(SandboxExtension::class);
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        $context["sidebar_first_exists"] =  !Twig\Extension\CoreExtension::testEmpty(Twig\Extension\CoreExtension::trim(Twig\Extension\CoreExtension::striptags($this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "sidebar_first", [], "any", false, false, true, 1), 1, $this->source)), "<img><video><audio><drupal-render-placeholder>")));
        // line 2
        $context["sidebar_second_exists"] =  !Twig\Extension\CoreExtension::testEmpty(Twig\Extension\CoreExtension::trim(Twig\Extension\CoreExtension::striptags($this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "sidebar_second", [], "any", false, false, true, 2), 2, $this->source)), "<img><video><audio><drupal-render-placeholder>")));
        // line 3
        yield "
<div id=\"page-wrapper\">
  <div id=\"page\">
    <header id=\"header\" class=\"header site-header";
        // line 6
        if (($context["is_front"] ?? null)) {
            yield " front-page-header";
        }
        yield "\" role=\"banner\" aria-label=\"";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Site header"));
        yield "\">
      <div class=\"container\">
        <nav class=\"navbar navbar-expand-lg navbar-light\">
          <div class=\"d-flex justify-content-between align-items-center header-block\">
            ";
        // line 10
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "header_top", [], "any", false, false, true, 10)) {
            // line 11
            yield "              <div class=\"header-top\">
                ";
            // line 12
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "header_top", [], "any", false, false, true, 12), 12, $this->source), "html", null, true);
            yield "
              </div>
            ";
        }
        // line 15
        yield "
            <button class=\"navbar-toggler\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#navbarSupportedContent\" aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
              <span class=\"navbar-toggler-icon\"></span>
            </button>
          </div>

          <div class=\"collapse navbar-collapse\" id=\"navbarSupportedContent\">
            <nav class=\"primary-menu w-100 \">
              ";
        // line 23
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "header_main", [], "any", false, false, true, 23), 23, $this->source), "html", null, true);
        yield "
            </nav>
          </div>
        </nav>
      </div>
    </header>
    <div class=\"banner\">
      <div class=\"banner-image\">
        ";
        // line 31
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "banner", [], "any", false, false, true, 31), 31, $this->source), "html", null, true);
        yield "
      </div>
      <div class=\"banner-text\">
        ";
        // line 34
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "banner_info", [], "any", false, false, true, 34), 34, $this->source), "html", null, true);
        yield "
      </div>
    </div>

    ";
        // line 38
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "highlighted", [], "any", false, false, true, 38)) {
            // line 39
            yield "      <div class=\"highlighted\">
        <aside class=\"";
            // line 40
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["container"] ?? null), 40, $this->source), "html", null, true);
            yield " section clearfix\" role=\"complementary\">
          ";
            // line 41
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "highlighted", [], "any", false, false, true, 41), 41, $this->source), "html", null, true);
            yield "
        </aside>
      </div>
    ";
        }
        // line 45
        yield "
    <div id=\"main-wrapper\" class=\"layout-main-wrapper ";
        // line 46
        if (($context["is_front"] ?? null)) {
            yield " front-page";
        }
        yield " clearfix\">
      ";
        // line 47
        yield from $this->unwrap()->yieldBlock('content', $context, $blocks);
        // line 60
        yield "    </div>

    ";
        // line 62
        if (((CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "featured_bottom_first", [], "any", false, false, true, 62) || CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "featured_bottom_second", [], "any", false, false, true, 62)) || CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "featured_bottom_third", [], "any", false, false, true, 62))) {
            // line 63
            yield "      <div class=\"featured-bottom\">
        <aside class=\"";
            // line 64
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["container"] ?? null), 64, $this->source), "html", null, true);
            yield " clearfix\" role=\"complementary\">
          ";
            // line 65
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "featured_bottom_first", [], "any", false, false, true, 65), 65, $this->source), "html", null, true);
            yield "
          ";
            // line 66
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "featured_bottom_second", [], "any", false, false, true, 66), 66, $this->source), "html", null, true);
            yield "
          ";
            // line 67
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "featured_bottom_third", [], "any", false, false, true, 67), 67, $this->source), "html", null, true);
            yield "
        </aside>
      </div>
    ";
        }
        // line 71
        yield "
    <footer class=\"site-footer\">
      ";
        // line 73
        yield from $this->unwrap()->yieldBlock('footer', $context, $blocks);
        // line 82
        yield "    </footer>
  </div>
</div>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["page", "is_front", "container", "content_attributes"]);        return; yield '';
    }

    // line 47
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 48
        yield "        <div id=\"main\" class=\"";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["container"] ?? null), 48, $this->source), "html", null, true);
        yield "\">
          ";
        // line 49
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "breadcrumb", [], "any", false, false, true, 49), 49, $this->source), "html", null, true);
        yield "
          <div class=\"row row-offcanvas row-offcanvas-left clearfix\">
            <main";
        // line 51
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["content_attributes"] ?? null), 51, $this->source), "html", null, true);
        yield ">
              <section class=\"section ";
        // line 52
        if (($context["is_front"] ?? null)) {
            yield " front-page";
        }
        yield "\">
                <a href=\"#main-content\" id=\"main-content\" tabindex=\"-1\"></a>
                ";
        // line 54
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "content", [], "any", false, false, true, 54), 54, $this->source), "html", null, true);
        yield "
              </section>
            </main>
          </div>
        </div>
      ";
        return; yield '';
    }

    // line 73
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 74
        yield "        <div class=\"";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["container"] ?? null), 74, $this->source), "html", null, true);
        yield "\">
          ";
        // line 75
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "footer_first", [], "any", false, false, true, 75)) {
            // line 76
            yield "            <div class=\"site-footer__top clearfix\">
              ";
            // line 77
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "footer_first", [], "any", false, false, true, 77), 77, $this->source), "html", null, true);
            yield "
            </div>
          ";
        }
        // line 80
        yield "        </div>
      ";
        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "themes/custom/exam/templates/layout/page.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  233 => 80,  227 => 77,  224 => 76,  222 => 75,  217 => 74,  213 => 73,  202 => 54,  195 => 52,  191 => 51,  186 => 49,  181 => 48,  177 => 47,  168 => 82,  166 => 73,  162 => 71,  155 => 67,  151 => 66,  147 => 65,  143 => 64,  140 => 63,  138 => 62,  134 => 60,  132 => 47,  126 => 46,  123 => 45,  116 => 41,  112 => 40,  109 => 39,  107 => 38,  100 => 34,  94 => 31,  83 => 23,  73 => 15,  67 => 12,  64 => 11,  62 => 10,  51 => 6,  46 => 3,  44 => 2,  42 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "themes/custom/exam/templates/layout/page.html.twig", "/var/www/web/themes/custom/exam/templates/layout/page.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 1, "if" => 6, "block" => 47);
        static $filters = array("trim" => 1, "striptags" => 1, "render" => 1, "t" => 6, "escape" => 12);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if', 'block'],
                ['trim', 'striptags', 'render', 't', 'escape'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
