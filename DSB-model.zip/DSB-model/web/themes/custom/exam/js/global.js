(function ($) {
  $(document).ready(function () {
    $('input[title="Search keywords"]').attr('title', 'Search');
  });
})(jQuery);

